const express = require("express");
const app = express();

console.log("🔥 app.js loaded");

const tiffinRoutes = require("./routes/tiffinRoutes");

app.use(express.json());

app.use((req, res, next) => {
    console.log(req.method, req.url);
    next();
});

app.get("/", (req, res) => {
    res.send("🚀 Welcome to OM Tiffin Management System API");
});

app.use("/api/tiffins", tiffinRoutes);

app.delete("/test", (req, res) => {
    res.json({
        success: true,
        message: "DELETE Route Working"
    });
});
module.exports = app;