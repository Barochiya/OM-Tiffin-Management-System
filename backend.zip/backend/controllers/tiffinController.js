console.log("✅ Controller Loaded");
const Tiffin = require("../models/Tiffin");

const createTiffin = async (req, res) => {
    console.log("🔥 createTiffin API Called");

    try {
        const tiffin = await Tiffin.create(req.body);

        res.status(201).json({
            success: true,
            data: tiffin,
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// Get All Tiffins
const getAllTiffins = async (req, res) => {
    try {
        const tiffins = await Tiffin.find();

        res.status(200).json({
            success: true,
            count: tiffins.length,
            data: tiffins,
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};



// Get Single Tiffin
const getTiffinById = async (req, res) => {
    try {
        const tiffin = await Tiffin.findById(req.params.id);

        if (!tiffin) {
            return res.status(404).json({
                success: false,
                message: "Customer not found",
            });
        }

        res.status(200).json({
            success: true,
            data: tiffin,
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};



// Update Tiffin
const updateTiffin = async (req, res) => {
    try {
        const tiffin = await Tiffin.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true,
            }
        );

        if (!tiffin) {
            return res.status(404).json({
                success: false,
                message: "Customer not found",
            });
        }

        res.status(200).json({
            success: true,
            data: tiffin,
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

// Delete Tiffin
const deleteTiffin = async (req, res) => {
    try {
        const tiffin = await Tiffin.findByIdAndDelete(req.params.id);

        if (!tiffin) {
            return res.status(404).json({
                success: false,
                message: "Customer not found",
            });
        }

        res.status(200).json({
            success: true,
            message: "Customer deleted successfully",
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message,
        });
    }
};

module.exports = {
    createTiffin,
    getAllTiffins,
    getTiffinById,
    updateTiffin,
    deleteTiffin,
};