const mongoose = require("mongoose");

const tiffinSchema = new mongoose.Schema(
{
    customerName: {
        type: String,
        required: true,
    },

    phone: {
        type: String,
        required: true,
    },

    address: {
        type: String,
        required: true,
    },

    mealType: {
        type: String,
        enum: ["Lunch", "Dinner", "Both"],
        default: "Lunch",
    },

    price: {
        type: Number,
        required: true,
    },

    status: {
        type: String,
        default: "Active",
    },
},
{
    timestamps: true,
}
);

module.exports = mongoose.model("Tiffin", tiffinSchema);