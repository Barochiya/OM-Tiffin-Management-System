const express = require("express");
const router = express.Router();

console.log("✅ Tiffin Routes Loaded");

const {
    createTiffin,
    getAllTiffins,
    getTiffinById,
    updateTiffin,
    deleteTiffin,
} = require("../controllers/tiffinController");

// Create Customer
router.post("/", createTiffin);

// Get All Customers
router.get("/", getAllTiffins);

// Get Single Customer
router.get("/:id", getTiffinById);

// Update Customer
router.put("/:id", updateTiffin);

// Delete Customer
console.log("✅ DELETE Route Registered");
router.delete("/:id", deleteTiffin);

console.log(router.stack.map(layer => ({
    path: layer.route?.path,
    methods: layer.route?.methods
})));
module.exports = router;